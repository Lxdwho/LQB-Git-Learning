/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *作者：鹏老师
	*时间：2023.3.20
	*CSDN：我是鹏老师
	*Bilibili：我是鹏老师
	*新版(G431)蓝桥杯嵌入式开发板，只卖199
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc2;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC2_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
uint8_t Key_Scan(void) //按键扫描函数
{   

	if(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0) == 0) //PB0 （按键B1）被按下
	{
		HAL_Delay(10);//延时消抖
		if(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0) == 0)
		{
			while(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0) == 0); //等待按键抬起
			return 1;//返回1
		}
	}
	
	if(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1) == 0) //PB1 （按键B2）被按下
	{
		HAL_Delay(10);//延时消抖
		if(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1) == 0)
		{
			while(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1) == 0); //等待按键抬起
			return 2;//返回2
		}
	}
	
	if(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_2) == 0) //PB2 （按键B3）被按下
	{
		HAL_Delay(10);//延时消抖
		if(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_2) == 0)
		{
			while(HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_2) == 0); //等待按键抬起
			return 3; //返回3
		}
	}
	
	if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == 0) //PA0 （按键B4）被按下
	{
		HAL_Delay(10);//延时消抖
		if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == 0)
		{
			while(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == 0); //等待按键抬起
			return 4; //返回4
		}
	}
	
	return 0; //没有按键按下返回0
}


uint16_t getADC2(void) // 获取PB15引脚的电压(对应R37电阻)
{
	uint16_t adc = 0;
	
	HAL_ADC_Start(&hadc2);
	adc = HAL_ADC_GetValue(&hadc2);
	
	return adc;
}


void LED_Control(int LED_Num, int Status)
{
	static unsigned char LED_status = 0xFF;
	
	if(LED_Num >8 || LED_Num < 1) return;
	
	if(Status == 0) //灯灭
	{
		LED_status |= (0x01 << (LED_Num-1));
	}
	else // 灯亮
	{
		LED_status &= ~(0x01 << (LED_Num-1));
	}
	GPIOC -> ODR = (LED_status << 8);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, 1);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, 0);
}

int time_flag = 0; //计时标志，0 计时停止，1 触发计时
int Time = 0; //计时的时间值
int time_ms = 0; //计时的mS时间值
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC2_Init();
  /* USER CODE BEGIN 2 */
	
	LCD_Init();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	
	LCD_Clear(Black);
	LCD_SetBackColor(Black);
	LCD_SetTextColor(White);
	
	int Key_Value = 0; //用于记录按键扫描的结果
	int page_index = 1; //页面编号
	double ADC_Value = 0; //ADC 数据
	
	double Vmax = 3.0; //参数Vmax
	double Vmin = 1.0; //参数Vmin
	
	double Vmax_L = 3.0; //调整中的参数Vmax
	double Vmin_L = 1.0; //调整中的参数Vmin
	
	char buf[64] = { 0 }; //字符串缓冲区
	
	LED_Control(2, 0); //实际上是关闭所有的LED灯
	
	int ADC_Status ; //用于记录上次ADC状态
	ADC_Value = 3.3 * getADC2() / 4095;
	
	if(ADC_Value > Vmax) ADC_Status = 3; //大于最大值，状态3
	else if(ADC_Value > Vmin) ADC_Status = 2; //最大值最小值之间，状态2
	else ADC_Status = 1; //小于最小值，状态1
	
  while (1)
  {
		int Now_ADC_Status; //当前ADC状态
		Key_Value = Key_Scan();
		ADC_Value = 3.3 * getADC2() / 4095;
		
		
		if(ADC_Value > Vmax) Now_ADC_Status = 3;
		else if(ADC_Value > Vmin) Now_ADC_Status = 2;
		else Now_ADC_Status = 1;
		
		//如果从状态1切换到状态2，触发计时
		if(ADC_Status == 1 && Now_ADC_Status == 2)
		{
			//LD1亮
			LED_Control(1, 1);
			time_flag = 1; //启动或重置计时
			Time = 0; //清零计时时间
			time_ms = 0; //清零计时毫秒时间
		}
		else if(ADC_Status == 2 && Now_ADC_Status == 3) //结束计时
		{
			//LD1灭
			LED_Control(1, 0);
			time_flag = 0; //结束计时
		}
		
		//当前状态 是 下一次的 上次状态
		ADC_Status = Now_ADC_Status; //更新状态
		
		if(Key_Value == 1) // B1被按下  切换页面
		{
			if(page_index == 1) //如果当前处于第一页
			{
				page_index = 2; //则切换到第二页(参数页面)
				
				Vmax_L = Vmax; //加载当前参数
				Vmin_L = Vmin;
			}
			else //切换回第一页(数据页面)
			{
				page_index = 1;
				if(Vmax_L >= Vmin_L +1) //参数合法，使用当前参数
				{
					Vmax = Vmax_L; //使参数生效
					Vmin = Vmin_L;
					
					//LD2 灭
					LED_Control(2, 0);
				}
				else //参数非法
				{
					//LD2 亮
					LED_Control(2, 1);
				}
			}
		}
		
		if(page_index == 1) //如果页面编号为1，则显示第一页（数据页面）的内容
		{
			LCD_DisplayStringLine(Line0, (uint8_t *)"      Data   ");
			
			sprintf(buf, " V:%.2fV    ",ADC_Value);
			LCD_DisplayStringLine(Line2, (uint8_t *)buf);
			
			sprintf(buf, " T:%ds    ",Time);
			LCD_DisplayStringLine(Line3, (uint8_t *)buf);
		}
		if(page_index == 2) //如果页面编号为2，则显示第二页（参数页面）的内容
		{
			LCD_DisplayStringLine(Line0, (uint8_t *)"      Para   ");
			
			sprintf(buf, " Vmax:%.1fV    ",Vmax_L);
			LCD_DisplayStringLine(Line2, (uint8_t *)buf);
			
			sprintf(buf, " Vmin:%.1fV    ",Vmin_L);
			LCD_DisplayStringLine(Line3, (uint8_t *)buf);
			
			if(Key_Value == 2) //B2被按下
			{
				Vmax_L += 0.1;
				
				if(Vmax_L > 3.31)
				{
					Vmax_L = 0.0000001;
				}
			}
			if(Key_Value == 3) //B3被按下
			{
				Vmin_L += 0.1;
				
				if(Vmin_L > 3.31)
				{
					Vmin_L = 0.0000001;
				}
			}
		}
		
		
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the CPU, AHB and APB busses clocks
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV2;
  RCC_OscInitStruct.PLL.PLLN = 20;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the peripherals clocks
  */
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC12;
  PeriphClkInit.Adc12ClockSelection = RCC_ADC12CLKSOURCE_SYSCLK;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC2_Init(void)
{

  /* USER CODE BEGIN ADC2_Init 0 */

  /* USER CODE END ADC2_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC2_Init 1 */

  /* USER CODE END ADC2_Init 1 */
  /** Common config
  */
  hadc2.Instance = ADC2;
  hadc2.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc2.Init.Resolution = ADC_RESOLUTION_12B;
  hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc2.Init.GainCompensation = 0;
  hadc2.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc2.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc2.Init.LowPowerAutoWait = DISABLE;
  hadc2.Init.ContinuousConvMode = DISABLE;
  hadc2.Init.NbrOfConversion = 1;
  hadc2.Init.DiscontinuousConvMode = DISABLE;
  hadc2.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc2.Init.DMAContinuousRequests = DISABLE;
  hadc2.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc2.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc2) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_15;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_2CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC2_Init 2 */

  /* USER CODE END ADC2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_0
                          |GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4
                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8
                          |GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5|GPIO_PIN_8|GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pins : PC13 PC14 PC15 PC0
                           PC1 PC2 PC3 PC4
                           PC5 PC6 PC7 PC8
                           PC9 PC10 PC11 PC12 */
  GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_0
                          |GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4
                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8
                          |GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB2 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PA8 */
  GPIO_InitStruct.Pin = GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PD2 */
  GPIO_InitStruct.Pin = GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : PB5 PB8 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_5|GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
